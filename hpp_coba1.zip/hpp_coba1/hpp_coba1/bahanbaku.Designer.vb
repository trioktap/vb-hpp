﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class bahanbaku
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tab1 = New System.Windows.Forms.TabControl()
        Me.tab_bb = New System.Windows.Forms.TabPage()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.HppDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HppDataSet = New hpp_coba1.hppDataSet()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.edit = New System.Windows.Forms.Button()
        Me.batal = New System.Windows.Forms.Button()
        Me.hapus = New System.Windows.Forms.Button()
        Me.simpan = New System.Windows.Forms.Button()
        Me.satuanbb = New System.Windows.Forms.ComboBox()
        Me.hargabb = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.stokbb = New System.Windows.Forms.TextBox()
        Me.namabb = New System.Windows.Forms.TextBox()
        Me.idbb = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tab_produk = New System.Windows.Forms.TabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.HppDataSet1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HppDataSet1 = New hpp_coba1.hppDataSet1()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.editproduk = New System.Windows.Forms.Button()
        Me.batal_produk = New System.Windows.Forms.Button()
        Me.hapus_produk = New System.Windows.Forms.Button()
        Me.simpan_produk = New System.Windows.Forms.Button()
        Me.namaproduk = New System.Windows.Forms.TextBox()
        Me.idproduk = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.tab_overhead = New System.Windows.Forms.TabPage()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.editoverhead = New System.Windows.Forms.Button()
        Me.bataloverhead = New System.Windows.Forms.Button()
        Me.hapusoverhead = New System.Windows.Forms.Button()
        Me.simpanoverhead = New System.Windows.Forms.Button()
        Me.satuanoverhead = New System.Windows.Forms.ComboBox()
        Me.hargaoverhead = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.namaoverhead = New System.Windows.Forms.TextBox()
        Me.idoverhead = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.pekerjaan = New System.Windows.Forms.TabPage()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.editpekerjaan = New System.Windows.Forms.Button()
        Me.batalpekerjaan = New System.Windows.Forms.Button()
        Me.hapuspekerjaan = New System.Windows.Forms.Button()
        Me.simpanpekerjaan = New System.Windows.Forms.Button()
        Me.satuanpekerjaan = New System.Windows.Forms.ComboBox()
        Me.hargapekerjaan = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.namapekerjaan = New System.Windows.Forms.TextBox()
        Me.idpekerjaan = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.loadbb = New System.Windows.Forms.Button()
        Me.tab1.SuspendLayout()
        Me.tab_bb.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HppDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HppDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.tab_produk.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HppDataSet1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HppDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.tab_overhead.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.pekerjaan.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'tab1
        '
        Me.tab1.Controls.Add(Me.tab_bb)
        Me.tab1.Controls.Add(Me.tab_produk)
        Me.tab1.Controls.Add(Me.tab_overhead)
        Me.tab1.Controls.Add(Me.pekerjaan)
        Me.tab1.Location = New System.Drawing.Point(1, 1)
        Me.tab1.Name = "tab1"
        Me.tab1.SelectedIndex = 0
        Me.tab1.Size = New System.Drawing.Size(779, 541)
        Me.tab1.TabIndex = 0
        '
        'tab_bb
        '
        Me.tab_bb.AutoScroll = True
        Me.tab_bb.BackColor = System.Drawing.Color.MediumPurple
        Me.tab_bb.Controls.Add(Me.loadbb)
        Me.tab_bb.Controls.Add(Me.CheckBox2)
        Me.tab_bb.Controls.Add(Me.CheckBox1)
        Me.tab_bb.Controls.Add(Me.TextBox5)
        Me.tab_bb.Controls.Add(Me.Label6)
        Me.tab_bb.Controls.Add(Me.DataGridView1)
        Me.tab_bb.Controls.Add(Me.GroupBox1)
        Me.tab_bb.Location = New System.Drawing.Point(4, 22)
        Me.tab_bb.Name = "tab_bb"
        Me.tab_bb.Padding = New System.Windows.Forms.Padding(3)
        Me.tab_bb.Size = New System.Drawing.Size(771, 515)
        Me.tab_bb.TabIndex = 0
        Me.tab_bb.Text = "Bahan Baku"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(193, 271)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(65, 23)
        Me.CheckBox2.TabIndex = 17
        Me.CheckBox2.Text = "Nama"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(93, 271)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox1.TabIndex = 16
        Me.CheckBox1.Text = "ID"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'TextBox5
        '
        Me.TextBox5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(93, 239)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(165, 26)
        Me.TextBox5.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(13, 242)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 19)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Search"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.DataSource = Me.HppDataSetBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(13, 294)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(709, 203)
        Me.DataGridView1.TabIndex = 1
        '
        'HppDataSetBindingSource
        '
        Me.HppDataSetBindingSource.DataSource = Me.HppDataSet
        Me.HppDataSetBindingSource.Position = 0
        '
        'HppDataSet
        '
        Me.HppDataSet.DataSetName = "hppDataSet"
        Me.HppDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.edit)
        Me.GroupBox1.Controls.Add(Me.batal)
        Me.GroupBox1.Controls.Add(Me.hapus)
        Me.GroupBox1.Controls.Add(Me.simpan)
        Me.GroupBox1.Controls.Add(Me.satuanbb)
        Me.GroupBox1.Controls.Add(Me.hargabb)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.stokbb)
        Me.GroupBox1.Controls.Add(Me.namabb)
        Me.GroupBox1.Controls.Add(Me.idbb)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(715, 213)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Input Bahan Baku"
        '
        'edit
        '
        Me.edit.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.edit.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.edit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.edit.Location = New System.Drawing.Point(197, 160)
        Me.edit.Name = "edit"
        Me.edit.Size = New System.Drawing.Size(112, 36)
        Me.edit.TabIndex = 14
        Me.edit.Text = "EDIT"
        Me.edit.UseVisualStyleBackColor = False
        '
        'batal
        '
        Me.batal.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.batal.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.batal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.batal.Location = New System.Drawing.Point(499, 160)
        Me.batal.Name = "batal"
        Me.batal.Size = New System.Drawing.Size(112, 36)
        Me.batal.TabIndex = 13
        Me.batal.Text = "BATAL"
        Me.batal.UseVisualStyleBackColor = False
        '
        'hapus
        '
        Me.hapus.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.hapus.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hapus.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.hapus.Location = New System.Drawing.Point(352, 160)
        Me.hapus.Name = "hapus"
        Me.hapus.Size = New System.Drawing.Size(112, 36)
        Me.hapus.TabIndex = 12
        Me.hapus.Text = "HAPUS"
        Me.hapus.UseVisualStyleBackColor = False
        '
        'simpan
        '
        Me.simpan.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.simpan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simpan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.simpan.Location = New System.Drawing.Point(48, 160)
        Me.simpan.Name = "simpan"
        Me.simpan.Size = New System.Drawing.Size(112, 36)
        Me.simpan.TabIndex = 11
        Me.simpan.Text = "SIMPAN"
        Me.simpan.UseVisualStyleBackColor = False
        '
        'satuanbb
        '
        Me.satuanbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.satuanbb.FormattingEnabled = True
        Me.satuanbb.Items.AddRange(New Object() {"Gram", "KG", "Liter", "ml"})
        Me.satuanbb.Location = New System.Drawing.Point(461, 30)
        Me.satuanbb.Name = "satuanbb"
        Me.satuanbb.Size = New System.Drawing.Size(165, 27)
        Me.satuanbb.TabIndex = 10
        '
        'hargabb
        '
        Me.hargabb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hargabb.Location = New System.Drawing.Point(461, 60)
        Me.hargabb.Name = "hargabb"
        Me.hargabb.Size = New System.Drawing.Size(165, 26)
        Me.hargabb.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(338, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 19)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Harga / Satuan"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(338, 33)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 19)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Satuan"
        '
        'stokbb
        '
        Me.stokbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stokbb.Location = New System.Drawing.Point(144, 90)
        Me.stokbb.Name = "stokbb"
        Me.stokbb.Size = New System.Drawing.Size(165, 26)
        Me.stokbb.TabIndex = 5
        '
        'namabb
        '
        Me.namabb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namabb.Location = New System.Drawing.Point(144, 58)
        Me.namabb.Name = "namabb"
        Me.namabb.Size = New System.Drawing.Size(165, 26)
        Me.namabb.TabIndex = 4
        '
        'idbb
        '
        Me.idbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idbb.Location = New System.Drawing.Point(144, 25)
        Me.idbb.Name = "idbb"
        Me.idbb.Size = New System.Drawing.Size(165, 26)
        Me.idbb.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 97)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 19)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Stok"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 19)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nama Bahan Baku"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID Bahan Baku"
        '
        'tab_produk
        '
        Me.tab_produk.AutoScroll = True
        Me.tab_produk.BackColor = System.Drawing.Color.MediumPurple
        Me.tab_produk.Controls.Add(Me.DataGridView2)
        Me.tab_produk.Controls.Add(Me.CheckBox3)
        Me.tab_produk.Controls.Add(Me.CheckBox4)
        Me.tab_produk.Controls.Add(Me.TextBox6)
        Me.tab_produk.Controls.Add(Me.Label7)
        Me.tab_produk.Controls.Add(Me.GroupBox2)
        Me.tab_produk.Location = New System.Drawing.Point(4, 22)
        Me.tab_produk.Name = "tab_produk"
        Me.tab_produk.Padding = New System.Windows.Forms.Padding(3)
        Me.tab_produk.Size = New System.Drawing.Size(771, 515)
        Me.tab_produk.TabIndex = 1
        Me.tab_produk.Text = "Produk"
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.DataSource = Me.HppDataSet1BindingSource
        Me.DataGridView2.Location = New System.Drawing.Point(14, 310)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(597, 175)
        Me.DataGridView2.TabIndex = 22
        '
        'HppDataSet1BindingSource
        '
        Me.HppDataSet1BindingSource.DataSource = Me.HppDataSet1
        Me.HppDataSet1BindingSource.Position = 0
        '
        'HppDataSet1
        '
        Me.HppDataSet1.DataSetName = "hppDataSet1"
        Me.HppDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox3.Location = New System.Drawing.Point(190, 281)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(65, 23)
        Me.CheckBox3.TabIndex = 21
        Me.CheckBox3.Text = "Nama"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox4.Location = New System.Drawing.Point(90, 281)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox4.TabIndex = 20
        Me.CheckBox4.Text = "ID"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'TextBox6
        '
        Me.TextBox6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(90, 249)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(165, 26)
        Me.TextBox6.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(10, 252)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 19)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Search"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.editproduk)
        Me.GroupBox2.Controls.Add(Me.batal_produk)
        Me.GroupBox2.Controls.Add(Me.hapus_produk)
        Me.GroupBox2.Controls.Add(Me.simpan_produk)
        Me.GroupBox2.Controls.Add(Me.namaproduk)
        Me.GroupBox2.Controls.Add(Me.idproduk)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Location = New System.Drawing.Point(7, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(605, 213)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Input Produk"
        '
        'editproduk
        '
        Me.editproduk.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.editproduk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.editproduk.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.editproduk.Location = New System.Drawing.Point(158, 129)
        Me.editproduk.Name = "editproduk"
        Me.editproduk.Size = New System.Drawing.Size(112, 36)
        Me.editproduk.TabIndex = 15
        Me.editproduk.Text = "EDIT"
        Me.editproduk.UseVisualStyleBackColor = False
        '
        'batal_produk
        '
        Me.batal_produk.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.batal_produk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.batal_produk.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.batal_produk.Location = New System.Drawing.Point(430, 129)
        Me.batal_produk.Name = "batal_produk"
        Me.batal_produk.Size = New System.Drawing.Size(112, 36)
        Me.batal_produk.TabIndex = 13
        Me.batal_produk.Text = "BATAL"
        Me.batal_produk.UseVisualStyleBackColor = False
        '
        'hapus_produk
        '
        Me.hapus_produk.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.hapus_produk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hapus_produk.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.hapus_produk.Location = New System.Drawing.Point(296, 129)
        Me.hapus_produk.Name = "hapus_produk"
        Me.hapus_produk.Size = New System.Drawing.Size(112, 36)
        Me.hapus_produk.TabIndex = 12
        Me.hapus_produk.Text = "HAPUS"
        Me.hapus_produk.UseVisualStyleBackColor = False
        '
        'simpan_produk
        '
        Me.simpan_produk.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.simpan_produk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simpan_produk.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.simpan_produk.Location = New System.Drawing.Point(24, 129)
        Me.simpan_produk.Name = "simpan_produk"
        Me.simpan_produk.Size = New System.Drawing.Size(112, 36)
        Me.simpan_produk.TabIndex = 11
        Me.simpan_produk.Text = "SIMPAN"
        Me.simpan_produk.UseVisualStyleBackColor = False
        '
        'namaproduk
        '
        Me.namaproduk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namaproduk.Location = New System.Drawing.Point(158, 73)
        Me.namaproduk.Name = "namaproduk"
        Me.namaproduk.Size = New System.Drawing.Size(165, 26)
        Me.namaproduk.TabIndex = 4
        '
        'idproduk
        '
        Me.idproduk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idproduk.Location = New System.Drawing.Point(158, 40)
        Me.idproduk.Name = "idproduk"
        Me.idproduk.Size = New System.Drawing.Size(165, 26)
        Me.idproduk.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(20, 80)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(95, 19)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Nama Produk"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(20, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 19)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "ID Produk"
        '
        'tab_overhead
        '
        Me.tab_overhead.AutoScroll = True
        Me.tab_overhead.BackColor = System.Drawing.Color.MediumPurple
        Me.tab_overhead.Controls.Add(Me.DataGridView3)
        Me.tab_overhead.Controls.Add(Me.CheckBox5)
        Me.tab_overhead.Controls.Add(Me.CheckBox6)
        Me.tab_overhead.Controls.Add(Me.TextBox1)
        Me.tab_overhead.Controls.Add(Me.Label8)
        Me.tab_overhead.Controls.Add(Me.GroupBox3)
        Me.tab_overhead.Location = New System.Drawing.Point(4, 22)
        Me.tab_overhead.Name = "tab_overhead"
        Me.tab_overhead.Padding = New System.Windows.Forms.Padding(3)
        Me.tab_overhead.Size = New System.Drawing.Size(771, 515)
        Me.tab_overhead.TabIndex = 2
        Me.tab_overhead.Text = "Overhead"
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(13, 269)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(707, 160)
        Me.DataGridView3.TabIndex = 26
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox5.Location = New System.Drawing.Point(189, 246)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(65, 23)
        Me.CheckBox5.TabIndex = 25
        Me.CheckBox5.Text = "Nama"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox6.Location = New System.Drawing.Point(89, 246)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox6.TabIndex = 24
        Me.CheckBox6.Text = "ID"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(89, 214)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(165, 26)
        Me.TextBox1.TabIndex = 23
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(9, 217)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 19)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Search"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.editoverhead)
        Me.GroupBox3.Controls.Add(Me.bataloverhead)
        Me.GroupBox3.Controls.Add(Me.hapusoverhead)
        Me.GroupBox3.Controls.Add(Me.simpanoverhead)
        Me.GroupBox3.Controls.Add(Me.satuanoverhead)
        Me.GroupBox3.Controls.Add(Me.hargaoverhead)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.namaoverhead)
        Me.GroupBox3.Controls.Add(Me.idoverhead)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(715, 179)
        Me.GroupBox3.TabIndex = 1
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Input Overhead"
        '
        'editoverhead
        '
        Me.editoverhead.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.editoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.editoverhead.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.editoverhead.Location = New System.Drawing.Point(187, 117)
        Me.editoverhead.Name = "editoverhead"
        Me.editoverhead.Size = New System.Drawing.Size(112, 36)
        Me.editoverhead.TabIndex = 14
        Me.editoverhead.Text = "EDIT"
        Me.editoverhead.UseVisualStyleBackColor = False
        '
        'bataloverhead
        '
        Me.bataloverhead.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.bataloverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bataloverhead.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.bataloverhead.Location = New System.Drawing.Point(493, 117)
        Me.bataloverhead.Name = "bataloverhead"
        Me.bataloverhead.Size = New System.Drawing.Size(112, 36)
        Me.bataloverhead.TabIndex = 13
        Me.bataloverhead.Text = "BATAL"
        Me.bataloverhead.UseVisualStyleBackColor = False
        '
        'hapusoverhead
        '
        Me.hapusoverhead.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.hapusoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hapusoverhead.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.hapusoverhead.Location = New System.Drawing.Point(342, 117)
        Me.hapusoverhead.Name = "hapusoverhead"
        Me.hapusoverhead.Size = New System.Drawing.Size(112, 36)
        Me.hapusoverhead.TabIndex = 12
        Me.hapusoverhead.Text = "HAPUS"
        Me.hapusoverhead.UseVisualStyleBackColor = False
        '
        'simpanoverhead
        '
        Me.simpanoverhead.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.simpanoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simpanoverhead.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.simpanoverhead.Location = New System.Drawing.Point(38, 117)
        Me.simpanoverhead.Name = "simpanoverhead"
        Me.simpanoverhead.Size = New System.Drawing.Size(112, 36)
        Me.simpanoverhead.TabIndex = 11
        Me.simpanoverhead.Text = "SIMPAN"
        Me.simpanoverhead.UseVisualStyleBackColor = False
        '
        'satuanoverhead
        '
        Me.satuanoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.satuanoverhead.FormattingEnabled = True
        Me.satuanoverhead.Items.AddRange(New Object() {"Watt", "Buah", "Jam", "Sesi"})
        Me.satuanoverhead.Location = New System.Drawing.Point(461, 30)
        Me.satuanoverhead.Name = "satuanoverhead"
        Me.satuanoverhead.Size = New System.Drawing.Size(165, 27)
        Me.satuanoverhead.TabIndex = 10
        '
        'hargaoverhead
        '
        Me.hargaoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hargaoverhead.Location = New System.Drawing.Point(461, 60)
        Me.hargaoverhead.Name = "hargaoverhead"
        Me.hargaoverhead.Size = New System.Drawing.Size(165, 26)
        Me.hargaoverhead.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(338, 65)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(99, 19)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "Harga / Satuan"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(338, 33)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(50, 19)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Satuan"
        '
        'namaoverhead
        '
        Me.namaoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namaoverhead.Location = New System.Drawing.Point(144, 58)
        Me.namaoverhead.Name = "namaoverhead"
        Me.namaoverhead.Size = New System.Drawing.Size(165, 26)
        Me.namaoverhead.TabIndex = 4
        '
        'idoverhead
        '
        Me.idoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idoverhead.Location = New System.Drawing.Point(144, 25)
        Me.idoverhead.Name = "idoverhead"
        Me.idoverhead.Size = New System.Drawing.Size(165, 26)
        Me.idoverhead.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(6, 65)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(110, 19)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Nama Overhead"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 28)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(89, 19)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "ID Overhead"
        '
        'pekerjaan
        '
        Me.pekerjaan.AutoScroll = True
        Me.pekerjaan.BackColor = System.Drawing.Color.MediumPurple
        Me.pekerjaan.Controls.Add(Me.DataGridView4)
        Me.pekerjaan.Controls.Add(Me.CheckBox7)
        Me.pekerjaan.Controls.Add(Me.CheckBox8)
        Me.pekerjaan.Controls.Add(Me.TextBox2)
        Me.pekerjaan.Controls.Add(Me.Label19)
        Me.pekerjaan.Controls.Add(Me.GroupBox4)
        Me.pekerjaan.Location = New System.Drawing.Point(4, 22)
        Me.pekerjaan.Name = "pekerjaan"
        Me.pekerjaan.Padding = New System.Windows.Forms.Padding(3)
        Me.pekerjaan.Size = New System.Drawing.Size(771, 515)
        Me.pekerjaan.TabIndex = 3
        Me.pekerjaan.Text = "Pekerja"
        Me.pekerjaan.UseWaitCursor = True
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(17, 280)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.Size = New System.Drawing.Size(704, 194)
        Me.DataGridView4.TabIndex = 30
        Me.DataGridView4.UseWaitCursor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox7.Location = New System.Drawing.Point(193, 250)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(65, 23)
        Me.CheckBox7.TabIndex = 29
        Me.CheckBox7.Text = "Nama"
        Me.CheckBox7.UseVisualStyleBackColor = True
        Me.CheckBox7.UseWaitCursor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox8.Location = New System.Drawing.Point(93, 250)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(44, 23)
        Me.CheckBox8.TabIndex = 28
        Me.CheckBox8.Text = "ID"
        Me.CheckBox8.UseVisualStyleBackColor = True
        Me.CheckBox8.UseWaitCursor = True
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(93, 218)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(165, 26)
        Me.TextBox2.TabIndex = 27
        Me.TextBox2.UseWaitCursor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(13, 221)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(51, 19)
        Me.Label19.TabIndex = 26
        Me.Label19.Text = "Search"
        Me.Label19.UseWaitCursor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.editpekerjaan)
        Me.GroupBox4.Controls.Add(Me.batalpekerjaan)
        Me.GroupBox4.Controls.Add(Me.hapuspekerjaan)
        Me.GroupBox4.Controls.Add(Me.simpanpekerjaan)
        Me.GroupBox4.Controls.Add(Me.satuanpekerjaan)
        Me.GroupBox4.Controls.Add(Me.hargapekerjaan)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.namapekerjaan)
        Me.GroupBox4.Controls.Add(Me.idpekerjaan)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Location = New System.Drawing.Point(7, 15)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(715, 179)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Input Pekerjaan"
        Me.GroupBox4.UseWaitCursor = True
        '
        'editpekerjaan
        '
        Me.editpekerjaan.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.editpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.editpekerjaan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.editpekerjaan.Location = New System.Drawing.Point(187, 117)
        Me.editpekerjaan.Name = "editpekerjaan"
        Me.editpekerjaan.Size = New System.Drawing.Size(112, 36)
        Me.editpekerjaan.TabIndex = 14
        Me.editpekerjaan.Text = "EDIT"
        Me.editpekerjaan.UseVisualStyleBackColor = False
        Me.editpekerjaan.UseWaitCursor = True
        '
        'batalpekerjaan
        '
        Me.batalpekerjaan.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.batalpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.batalpekerjaan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.batalpekerjaan.Location = New System.Drawing.Point(493, 117)
        Me.batalpekerjaan.Name = "batalpekerjaan"
        Me.batalpekerjaan.Size = New System.Drawing.Size(112, 36)
        Me.batalpekerjaan.TabIndex = 13
        Me.batalpekerjaan.Text = "BATAL"
        Me.batalpekerjaan.UseVisualStyleBackColor = False
        Me.batalpekerjaan.UseWaitCursor = True
        '
        'hapuspekerjaan
        '
        Me.hapuspekerjaan.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.hapuspekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hapuspekerjaan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.hapuspekerjaan.Location = New System.Drawing.Point(342, 117)
        Me.hapuspekerjaan.Name = "hapuspekerjaan"
        Me.hapuspekerjaan.Size = New System.Drawing.Size(112, 36)
        Me.hapuspekerjaan.TabIndex = 12
        Me.hapuspekerjaan.Text = "HAPUS"
        Me.hapuspekerjaan.UseVisualStyleBackColor = False
        Me.hapuspekerjaan.UseWaitCursor = True
        '
        'simpanpekerjaan
        '
        Me.simpanpekerjaan.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.simpanpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simpanpekerjaan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.simpanpekerjaan.Location = New System.Drawing.Point(40, 117)
        Me.simpanpekerjaan.Name = "simpanpekerjaan"
        Me.simpanpekerjaan.Size = New System.Drawing.Size(112, 36)
        Me.simpanpekerjaan.TabIndex = 11
        Me.simpanpekerjaan.Text = "SIMPAN"
        Me.simpanpekerjaan.UseVisualStyleBackColor = False
        Me.simpanpekerjaan.UseWaitCursor = True
        '
        'satuanpekerjaan
        '
        Me.satuanpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.satuanpekerjaan.FormattingEnabled = True
        Me.satuanpekerjaan.Items.AddRange(New Object() {"Jam", "Hari", "Minggu", "Orang"})
        Me.satuanpekerjaan.Location = New System.Drawing.Point(461, 30)
        Me.satuanpekerjaan.Name = "satuanpekerjaan"
        Me.satuanpekerjaan.Size = New System.Drawing.Size(165, 27)
        Me.satuanpekerjaan.TabIndex = 10
        Me.satuanpekerjaan.UseWaitCursor = True
        '
        'hargapekerjaan
        '
        Me.hargapekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hargapekerjaan.Location = New System.Drawing.Point(461, 60)
        Me.hargapekerjaan.Name = "hargapekerjaan"
        Me.hargapekerjaan.Size = New System.Drawing.Size(165, 26)
        Me.hargapekerjaan.TabIndex = 9
        Me.hargapekerjaan.UseWaitCursor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(338, 65)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(99, 19)
        Me.Label15.TabIndex = 7
        Me.Label15.Text = "Harga / Satuan"
        Me.Label15.UseWaitCursor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(338, 33)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(50, 19)
        Me.Label16.TabIndex = 6
        Me.Label16.Text = "Satuan"
        Me.Label16.UseWaitCursor = True
        '
        'namapekerjaan
        '
        Me.namapekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namapekerjaan.Location = New System.Drawing.Point(144, 58)
        Me.namapekerjaan.Name = "namapekerjaan"
        Me.namapekerjaan.Size = New System.Drawing.Size(165, 26)
        Me.namapekerjaan.TabIndex = 4
        Me.namapekerjaan.UseWaitCursor = True
        '
        'idpekerjaan
        '
        Me.idpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idpekerjaan.Location = New System.Drawing.Point(144, 25)
        Me.idpekerjaan.Name = "idpekerjaan"
        Me.idpekerjaan.Size = New System.Drawing.Size(165, 26)
        Me.idpekerjaan.TabIndex = 3
        Me.idpekerjaan.UseWaitCursor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 65)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(111, 19)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Nama Pekerjaan"
        Me.Label17.UseWaitCursor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(6, 28)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(90, 19)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "ID Pekerjaan"
        Me.Label18.UseWaitCursor = True
        '
        'loadbb
        '
        Me.loadbb.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.loadbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loadbb.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.loadbb.Location = New System.Drawing.Point(610, 252)
        Me.loadbb.Name = "loadbb"
        Me.loadbb.Size = New System.Drawing.Size(112, 36)
        Me.loadbb.TabIndex = 15
        Me.loadbb.Text = "LOAD"
        Me.loadbb.UseVisualStyleBackColor = False
        '
        'bahanbaku
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.MediumPurple
        Me.ClientSize = New System.Drawing.Size(800, 543)
        Me.Controls.Add(Me.tab1)
        Me.Name = "bahanbaku"
        Me.Text = "bahanbaku"
        Me.tab1.ResumeLayout(False)
        Me.tab_bb.ResumeLayout(False)
        Me.tab_bb.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HppDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HppDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tab_produk.ResumeLayout(False)
        Me.tab_produk.PerformLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HppDataSet1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HppDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.tab_overhead.ResumeLayout(False)
        Me.tab_overhead.PerformLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.pekerjaan.ResumeLayout(False)
        Me.pekerjaan.PerformLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents tab1 As TabControl
    Friend WithEvents tab_bb As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents tab_produk As TabPage
    Friend WithEvents tab_overhead As TabPage
    Friend WithEvents pekerjaan As TabPage
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents HppDataSetBindingSource As BindingSource
    Friend WithEvents HppDataSet As hppDataSet
    Friend WithEvents batal As Button
    Friend WithEvents hapus As Button
    Friend WithEvents simpan As Button
    Friend WithEvents satuanbb As ComboBox
    Friend WithEvents hargabb As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents stokbb As TextBox
    Friend WithEvents namabb As TextBox
    Friend WithEvents idbb As TextBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents batal_produk As Button
    Friend WithEvents hapus_produk As Button
    Friend WithEvents simpan_produk As Button
    Friend WithEvents namaproduk As TextBox
    Friend WithEvents idproduk As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents HppDataSet1BindingSource As BindingSource
    Friend WithEvents HppDataSet1 As hppDataSet1
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents edit As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents editoverhead As Button
    Friend WithEvents bataloverhead As Button
    Friend WithEvents hapusoverhead As Button
    Friend WithEvents simpanoverhead As Button
    Friend WithEvents satuanoverhead As ComboBox
    Friend WithEvents hargaoverhead As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents namaoverhead As TextBox
    Friend WithEvents idoverhead As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents editproduk As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents editpekerjaan As Button
    Friend WithEvents batalpekerjaan As Button
    Friend WithEvents hapuspekerjaan As Button
    Friend WithEvents simpanpekerjaan As Button
    Friend WithEvents satuanpekerjaan As ComboBox
    Friend WithEvents hargapekerjaan As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents namapekerjaan As TextBox
    Friend WithEvents idpekerjaan As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents DataGridView4 As DataGridView
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents loadbb As Button
End Class
