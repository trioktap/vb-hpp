﻿Imports MySql.Data.MySqlClient

Public Class hpp
    Dim Connection As New MySqlConnection("server=localhost;user id=root;database=hpp")

    Private Sub addproduksi_Click(sender As Object, e As EventArgs) Handles addproduksi.Click
        Dim command As New MySqlCommand("INSERT INTO `produksi`(`id_produksi`, `tgl_produksi`) VALUES (@idproduksi,@tglproduksi)",
                                        Connection)

        command.Parameters.Add("@idproduksi", MySqlDbType.VarChar).Value = idproduksi.Text
        command.Parameters.Add("@tglproduksi", MySqlDbType.VarChar).Value = tglproduksi.Text

        Connection.Open()

        If command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Data Berhasil Disimpan!")
        Else
            MessageBox.Show("Data Tidak Dapat Disimpan!")
        End If
    End Sub
End Class