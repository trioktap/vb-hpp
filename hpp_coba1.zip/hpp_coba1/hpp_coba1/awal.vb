﻿Public Class awal
    Private Sub btnmaster_Click(sender As Object, e As EventArgs) Handles btnmaster.Click
        bahanbaku.Show()
    End Sub

    Private Sub btnhpp_Click(sender As Object, e As EventArgs) Handles btnhpp.Click
        hpp.Show()
    End Sub
End Class