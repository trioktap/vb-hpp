﻿Imports MySql.Data.MySqlClient

Public Class bahanbaku
    Dim Connection As New MySqlConnection("server=localhost;user id=root;database=hpp")
    Dim dt As New DataTable()


    Private Sub simpan_Click(sender As Object, e As EventArgs) Handles simpan.Click
        Dim command As New MySqlCommand("INSERT INTO `bahan_baku`(`id_bb`, `nama_bb`, `stok`, `satuan`, `harga_satuan`) VALUES (@idbb,@namabb,@stokbb,@satuanbb,@hargabb)", Connection)

        command.Parameters.Add("@idbb", MySqlDbType.VarChar).Value = idbb.Text
        command.Parameters.Add("@namabb", MySqlDbType.VarChar).Value = namabb.Text
        command.Parameters.Add("@stokbb", MySqlDbType.Int16).Value = stokbb.Text
        command.Parameters.Add("@satuanbb", MySqlDbType.VarChar).Value = satuanbb.Text
        command.Parameters.Add("@hargabb", MySqlDbType.Int32).Value = hargabb.Text

        Connection.Open()

        If command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Data Berhasil Disimpan!")
        Else
            MessageBox.Show("Data Tidak Dapat Disimpan!")
        End If

        Connection.Close()
        Show()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick



    End Sub

    Private Sub hapus_Click(sender As Object, e As EventArgs) Handles hapus.Click
        Dim command As New MySqlCommand("DELETE FROM `bahan_baku` WHERE nama_bb=" + namabb.Text + "'")

        Connection.Open()

        If command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Data Berhasil Dihapus!")
        Else
            MessageBox.Show("Data Gagal Dihapus!")
        End If

        Connection.Close()

        Show()
    End Sub

    Private Sub simpan_produk_Click(sender As Object, e As EventArgs) Handles simpan_produk.Click
        Dim command As New MySqlCommand("INSERT INTO `produk`(`id_produk`, `nama_produk`) VALUES (@idproduk,@namaproduk)", Connection)
        command.Parameters.Add("@idproduk", MySqlDbType.VarChar).Value = idproduk.Text
        command.Parameters.Add("@namaproduk", MySqlDbType.VarChar).Value = namaproduk.Text

        Connection.Open()

        If command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Data Berhasil Disimpan!")
        Else
            MessageBox.Show("Data Tidak Dapat Disimpan!")
        End If

        Connection.Close()
        Show()
    End Sub

    Private Sub simpanoverhead_Click(sender As Object, e As EventArgs) Handles simpanoverhead.Click
        Dim command As New MySqlCommand("INSERT INTO `overhead`(`id_overhead`, `nama_overhead`, `satuan`, `biaya_satuan`) VALUES (@idoverhead,@namaoverhead,@satuanoverhead,@hargaoverhead)", Connection)

        command.Parameters.Add("@idoverhead", MySqlDbType.VarChar).Value = idoverhead.Text
        command.Parameters.Add("@namaoverhead", MySqlDbType.VarChar).Value = namaoverhead.Text
        command.Parameters.Add("@satuanoverhead", MySqlDbType.VarChar).Value = satuanoverhead.Text
        command.Parameters.Add("@hargaoverhead", MySqlDbType.Int32).Value = hargaoverhead.Text

        Connection.Open()

        If command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Data Berhasil Disimpan!")
        Else
            MessageBox.Show("Data Tidak Dapat Disimpan!")
        End If

        Connection.Close()
        Show()
    End Sub

    Private Sub simpanpekerjaan_Click(sender As Object, e As EventArgs) Handles simpanpekerjaan.Click
        Dim command As New MySqlCommand("INSERT INTO `tenaga_kerja`(`id_pekerjaan`, `nama_pekerjaan`, `satuan`, `biaya`) VALUES (@idpekerjaan,@namapekerjaan,@satuanpekerjaan,@hargapekerjaan)", Connection)

        command.Parameters.Add("@idpekerjaan", MySqlDbType.VarChar).Value = idpekerjaan.Text
        command.Parameters.Add("@namapekerjaan", MySqlDbType.VarChar).Value = namapekerjaan.Text
        command.Parameters.Add("@satuanpekerjaan", MySqlDbType.VarChar).Value = satuanpekerjaan.Text
        command.Parameters.Add("@hargapekerjaan", MySqlDbType.Int32).Value = hargapekerjaan.Text

        Connection.Open()

        If command.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Data Berhasil Disimpan!")
        Else
            MessageBox.Show("Data Tidak Dapat Disimpan!")
        End If

        Connection.Close()
        Show()
    End Sub

End Class