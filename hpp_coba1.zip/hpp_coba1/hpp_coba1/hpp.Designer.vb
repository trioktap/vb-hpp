﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class hpp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.simpanhpp = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.totalbbhpp = New System.Windows.Forms.TextBox()
        Me.totalhpp = New System.Windows.Forms.TextBox()
        Me.hitunghpp = New System.Windows.Forms.Button()
        Me.totaloverhpp = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.produkhpp = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.totalpekerjahpp = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.jmlhpp = New System.Windows.Forms.TextBox()
        Me.idhpp = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.totalpekerjaan = New System.Windows.Forms.TextBox()
        Me.addpekerja = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.jmlpekerjaan = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.hargapekerjaan = New System.Windows.Forms.TextBox()
        Me.idpekerjaan = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.satuanpekerjaan = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.totalbb = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.hargabb = New System.Windows.Forms.TextBox()
        Me.addbb = New System.Windows.Forms.Button()
        Me.satuanbb = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.idbb = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.jmlbb = New System.Windows.Forms.TextBox()
        Me.Produksi = New System.Windows.Forms.GroupBox()
        Me.tglproduksi = New System.Windows.Forms.DateTimePicker()
        Me.addproduksi = New System.Windows.Forms.Button()
        Me.idproduk = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.idproduksi = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.editjual = New System.Windows.Forms.Button()
        Me.bataljual = New System.Windows.Forms.Button()
        Me.hapusjual = New System.Windows.Forms.Button()
        Me.simpanjual = New System.Windows.Forms.Button()
        Me.tglhargajual = New System.Windows.Forms.DateTimePicker()
        Me.namaprodukjual = New System.Windows.Forms.ComboBox()
        Me.jmlprodukjual = New System.Windows.Forms.TextBox()
        Me.idhppjual = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.profit = New System.Windows.Forms.TextBox()
        Me.idprodukjual = New System.Windows.Forms.TextBox()
        Me.hargajual = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.hppjual = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.idhargajual = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.hpptotaloverhead = New System.Windows.Forms.TextBox()
        Me.addoverhead = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.hpphargaoverhead = New System.Windows.Forms.TextBox()
        Me.hppidoverhead = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.hppsatuanoverhead = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.combobb = New System.Windows.Forms.ComboBox()
        Me.combopekerjaan = New System.Windows.Forms.ComboBox()
        Me.combooverhead = New System.Windows.Forms.ComboBox()
        Me.comboproduk = New System.Windows.Forms.ComboBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Produksi.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(-3, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1361, 750)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.BackColor = System.Drawing.Color.MediumPurple
        Me.TabPage1.Controls.Add(Me.DataGridView5)
        Me.TabPage1.Controls.Add(Me.GroupBox4)
        Me.TabPage1.Controls.Add(Me.DataGridView4)
        Me.TabPage1.Controls.Add(Me.DataGridView3)
        Me.TabPage1.Controls.Add(Me.DataGridView2)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.Produksi)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1353, 724)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Harga Pokok Produksi"
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(735, 505)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.Size = New System.Drawing.Size(602, 193)
        Me.DataGridView4.TabIndex = 7
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(735, 205)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(599, 125)
        Me.DataGridView3.TabIndex = 6
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(735, 32)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(602, 144)
        Me.DataGridView2.TabIndex = 5
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.simpanhpp)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.totalbbhpp)
        Me.GroupBox3.Controls.Add(Me.totalhpp)
        Me.GroupBox3.Controls.Add(Me.hitunghpp)
        Me.GroupBox3.Controls.Add(Me.totaloverhpp)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.produkhpp)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.totalpekerjahpp)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.jmlhpp)
        Me.GroupBox3.Controls.Add(Me.idhpp)
        Me.GroupBox3.Location = New System.Drawing.Point(10, 495)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(701, 203)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Perhitungan HPP"
        '
        'simpanhpp
        '
        Me.simpanhpp.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.simpanhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simpanhpp.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.simpanhpp.Location = New System.Drawing.Point(354, 161)
        Me.simpanhpp.Name = "simpanhpp"
        Me.simpanhpp.Size = New System.Drawing.Size(93, 36)
        Me.simpanhpp.TabIndex = 50
        Me.simpanhpp.Text = "Simpan"
        Me.simpanhpp.UseVisualStyleBackColor = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(11, 129)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(63, 19)
        Me.Label23.TabIndex = 48
        Me.Label23.Text = "Total BB"
        '
        'totalbbhpp
        '
        Me.totalbbhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalbbhpp.Location = New System.Drawing.Point(119, 129)
        Me.totalbbhpp.Name = "totalbbhpp"
        Me.totalbbhpp.Size = New System.Drawing.Size(163, 26)
        Me.totalbbhpp.TabIndex = 49
        '
        'totalhpp
        '
        Me.totalhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalhpp.Location = New System.Drawing.Point(418, 97)
        Me.totalhpp.Name = "totalhpp"
        Me.totalhpp.Size = New System.Drawing.Size(163, 26)
        Me.totalhpp.TabIndex = 47
        '
        'hitunghpp
        '
        Me.hitunghpp.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.hitunghpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hitunghpp.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.hitunghpp.Location = New System.Drawing.Point(207, 161)
        Me.hitunghpp.Name = "hitunghpp"
        Me.hitunghpp.Size = New System.Drawing.Size(93, 36)
        Me.hitunghpp.TabIndex = 43
        Me.hitunghpp.Text = "Hitung"
        Me.hitunghpp.UseVisualStyleBackColor = False
        '
        'totaloverhpp
        '
        Me.totaloverhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totaloverhpp.Location = New System.Drawing.Point(418, 26)
        Me.totaloverhpp.Name = "totaloverhpp"
        Me.totaloverhpp.Size = New System.Drawing.Size(163, 26)
        Me.totaloverhpp.TabIndex = 41
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(10, 97)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(54, 19)
        Me.Label17.TabIndex = 44
        Me.Label17.Text = "Jumlah "
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(10, 29)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 19)
        Me.Label22.TabIndex = 35
        Me.Label22.Text = "ID HPP"
        '
        'produkhpp
        '
        Me.produkhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.produkhpp.Location = New System.Drawing.Point(118, 61)
        Me.produkhpp.Name = "produkhpp"
        Me.produkhpp.Size = New System.Drawing.Size(163, 26)
        Me.produkhpp.TabIndex = 38
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(10, 61)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(95, 19)
        Me.Label21.TabIndex = 36
        Me.Label21.Text = "Nama Produk"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(300, 97)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(38, 19)
        Me.Label18.TabIndex = 46
        Me.Label18.Text = "HPP"
        '
        'totalpekerjahpp
        '
        Me.totalpekerjahpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalpekerjahpp.Location = New System.Drawing.Point(418, 61)
        Me.totalpekerjahpp.Name = "totalpekerjahpp"
        Me.totalpekerjahpp.Size = New System.Drawing.Size(163, 26)
        Me.totalpekerjahpp.TabIndex = 42
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(300, 29)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(103, 19)
        Me.Label19.TabIndex = 39
        Me.Label19.Text = "Total Overhead"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(300, 61)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(90, 19)
        Me.Label20.TabIndex = 40
        Me.Label20.Text = "Total Pekerja"
        '
        'jmlhpp
        '
        Me.jmlhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.jmlhpp.Location = New System.Drawing.Point(118, 97)
        Me.jmlhpp.Name = "jmlhpp"
        Me.jmlhpp.Size = New System.Drawing.Size(163, 26)
        Me.jmlhpp.TabIndex = 45
        '
        'idhpp
        '
        Me.idhpp.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idhpp.Location = New System.Drawing.Point(119, 26)
        Me.idhpp.Name = "idhpp"
        Me.idhpp.Size = New System.Drawing.Size(163, 26)
        Me.idhpp.TabIndex = 37
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.combopekerjaan)
        Me.GroupBox2.Controls.Add(Me.totalpekerjaan)
        Me.GroupBox2.Controls.Add(Me.addpekerja)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.jmlpekerjaan)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.hargapekerjaan)
        Me.GroupBox2.Controls.Add(Me.idpekerjaan)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.satuanpekerjaan)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Location = New System.Drawing.Point(10, 233)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(699, 125)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Biaya Pekerja"
        '
        'totalpekerjaan
        '
        Me.totalpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalpekerjaan.Location = New System.Drawing.Point(409, 92)
        Me.totalpekerjaan.Name = "totalpekerjaan"
        Me.totalpekerjaan.Size = New System.Drawing.Size(163, 26)
        Me.totalpekerjaan.TabIndex = 34
        '
        'addpekerja
        '
        Me.addpekerja.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.addpekerja.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addpekerja.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.addpekerja.Location = New System.Drawing.Point(587, 50)
        Me.addpekerja.Name = "addpekerja"
        Me.addpekerja.Size = New System.Drawing.Size(93, 36)
        Me.addpekerja.TabIndex = 30
        Me.addpekerja.Text = "Add"
        Me.addpekerja.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(1, 92)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(99, 19)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Harga / Satuan"
        '
        'jmlpekerjaan
        '
        Me.jmlpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.jmlpekerjaan.Location = New System.Drawing.Point(109, 56)
        Me.jmlpekerjaan.Name = "jmlpekerjaan"
        Me.jmlpekerjaan.Size = New System.Drawing.Size(163, 26)
        Me.jmlpekerjaan.TabIndex = 25
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(291, 92)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(39, 19)
        Me.Label12.TabIndex = 33
        Me.Label12.Text = "Total"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(291, 24)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 19)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "Pekerjaan"
        '
        'hargapekerjaan
        '
        Me.hargapekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hargapekerjaan.Location = New System.Drawing.Point(109, 92)
        Me.hargapekerjaan.Name = "hargapekerjaan"
        Me.hargapekerjaan.Size = New System.Drawing.Size(163, 26)
        Me.hargapekerjaan.TabIndex = 32
        '
        'idpekerjaan
        '
        Me.idpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idpekerjaan.Location = New System.Drawing.Point(110, 21)
        Me.idpekerjaan.Name = "idpekerjaan"
        Me.idpekerjaan.Size = New System.Drawing.Size(163, 26)
        Me.idpekerjaan.TabIndex = 24
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(291, 56)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(50, 19)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "Satuan"
        '
        'satuanpekerjaan
        '
        Me.satuanpekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.satuanpekerjaan.Location = New System.Drawing.Point(409, 56)
        Me.satuanpekerjaan.Name = "satuanpekerjaan"
        Me.satuanpekerjaan.Size = New System.Drawing.Size(163, 26)
        Me.satuanpekerjaan.TabIndex = 29
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(1, 56)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(50, 19)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "Jumlah"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(1, 24)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 19)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "ID Pekerjaan"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.combobb)
        Me.GroupBox1.Controls.Add(Me.totalbb)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.hargabb)
        Me.GroupBox1.Controls.Add(Me.addbb)
        Me.GroupBox1.Controls.Add(Me.satuanbb)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.idbb)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.jmlbb)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 97)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(703, 130)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Bahan Baku"
        '
        'totalbb
        '
        Me.totalbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalbb.Location = New System.Drawing.Point(413, 96)
        Me.totalbb.Name = "totalbb"
        Me.totalbb.Size = New System.Drawing.Size(163, 26)
        Me.totalbb.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(5, 96)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(99, 19)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Harga / Satuan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(295, 96)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 19)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Total"
        '
        'hargabb
        '
        Me.hargabb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hargabb.Location = New System.Drawing.Point(113, 96)
        Me.hargabb.Name = "hargabb"
        Me.hargabb.Size = New System.Drawing.Size(163, 26)
        Me.hargabb.TabIndex = 19
        '
        'addbb
        '
        Me.addbb.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.addbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addbb.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.addbb.Location = New System.Drawing.Point(591, 54)
        Me.addbb.Name = "addbb"
        Me.addbb.Size = New System.Drawing.Size(93, 36)
        Me.addbb.TabIndex = 17
        Me.addbb.Text = "Add"
        Me.addbb.UseVisualStyleBackColor = False
        '
        'satuanbb
        '
        Me.satuanbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.satuanbb.Location = New System.Drawing.Point(413, 60)
        Me.satuanbb.Name = "satuanbb"
        Me.satuanbb.Size = New System.Drawing.Size(163, 26)
        Me.satuanbb.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(5, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(103, 19)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "ID Bahan Baku"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(5, 60)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 19)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Jumlah"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(295, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 19)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Satuan"
        '
        'idbb
        '
        Me.idbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idbb.Location = New System.Drawing.Point(114, 25)
        Me.idbb.Name = "idbb"
        Me.idbb.Size = New System.Drawing.Size(163, 26)
        Me.idbb.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(295, 28)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 19)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Bahan Baku"
        '
        'jmlbb
        '
        Me.jmlbb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.jmlbb.Location = New System.Drawing.Point(113, 60)
        Me.jmlbb.Name = "jmlbb"
        Me.jmlbb.Size = New System.Drawing.Size(163, 26)
        Me.jmlbb.TabIndex = 12
        '
        'Produksi
        '
        Me.Produksi.Controls.Add(Me.comboproduk)
        Me.Produksi.Controls.Add(Me.tglproduksi)
        Me.Produksi.Controls.Add(Me.addproduksi)
        Me.Produksi.Controls.Add(Me.idproduk)
        Me.Produksi.Controls.Add(Me.Label3)
        Me.Produksi.Controls.Add(Me.Label4)
        Me.Produksi.Controls.Add(Me.idproduksi)
        Me.Produksi.Controls.Add(Me.Label2)
        Me.Produksi.Controls.Add(Me.Label1)
        Me.Produksi.Location = New System.Drawing.Point(6, 3)
        Me.Produksi.Name = "Produksi"
        Me.Produksi.Size = New System.Drawing.Size(705, 88)
        Me.Produksi.TabIndex = 0
        Me.Produksi.TabStop = False
        Me.Produksi.Text = "Produksi"
        '
        'tglproduksi
        '
        Me.tglproduksi.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tglproduksi.Location = New System.Drawing.Point(114, 48)
        Me.tglproduksi.Name = "tglproduksi"
        Me.tglproduksi.Size = New System.Drawing.Size(164, 26)
        Me.tglproduksi.TabIndex = 32
        '
        'addproduksi
        '
        Me.addproduksi.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.addproduksi.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addproduksi.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.addproduksi.Location = New System.Drawing.Point(592, 31)
        Me.addproduksi.Name = "addproduksi"
        Me.addproduksi.Size = New System.Drawing.Size(93, 36)
        Me.addproduksi.TabIndex = 8
        Me.addproduksi.Text = "Add"
        Me.addproduksi.UseVisualStyleBackColor = False
        '
        'idproduk
        '
        Me.idproduk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idproduk.Location = New System.Drawing.Point(414, 13)
        Me.idproduk.Name = "idproduk"
        Me.idproduk.Size = New System.Drawing.Size(163, 26)
        Me.idproduk.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(296, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 19)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Nama Produk"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(296, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 19)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "ID Produk"
        '
        'idproduksi
        '
        Me.idproduksi.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idproduksi.Location = New System.Drawing.Point(114, 13)
        Me.idproduksi.Name = "idproduksi"
        Me.idproduksi.Size = New System.Drawing.Size(163, 26)
        Me.idproduksi.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 19)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tanggal"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID Produksi"
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.BackColor = System.Drawing.Color.MediumPurple
        Me.TabPage2.Controls.Add(Me.Label33)
        Me.TabPage2.Controls.Add(Me.DataGridView1)
        Me.TabPage2.Controls.Add(Me.editjual)
        Me.TabPage2.Controls.Add(Me.bataljual)
        Me.TabPage2.Controls.Add(Me.hapusjual)
        Me.TabPage2.Controls.Add(Me.simpanjual)
        Me.TabPage2.Controls.Add(Me.tglhargajual)
        Me.TabPage2.Controls.Add(Me.namaprodukjual)
        Me.TabPage2.Controls.Add(Me.jmlprodukjual)
        Me.TabPage2.Controls.Add(Me.idhppjual)
        Me.TabPage2.Controls.Add(Me.Label29)
        Me.TabPage2.Controls.Add(Me.profit)
        Me.TabPage2.Controls.Add(Me.idprodukjual)
        Me.TabPage2.Controls.Add(Me.hargajual)
        Me.TabPage2.Controls.Add(Me.Label30)
        Me.TabPage2.Controls.Add(Me.Label31)
        Me.TabPage2.Controls.Add(Me.Label32)
        Me.TabPage2.Controls.Add(Me.hppjual)
        Me.TabPage2.Controls.Add(Me.Label24)
        Me.TabPage2.Controls.Add(Me.Label25)
        Me.TabPage2.Controls.Add(Me.idhargajual)
        Me.TabPage2.Controls.Add(Me.Label26)
        Me.TabPage2.Controls.Add(Me.Label27)
        Me.TabPage2.Controls.Add(Me.Label28)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1353, 724)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Harga Jual"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Times New Roman", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label33.Location = New System.Drawing.Point(414, 18)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(514, 46)
        Me.Label33.TabIndex = 37
        Me.Label33.Text = "PENENTUAN HARGA JUAL"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(39, 388)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(808, 305)
        Me.DataGridView1.TabIndex = 36
        '
        'editjual
        '
        Me.editjual.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.editjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.editjual.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.editjual.Location = New System.Drawing.Point(188, 329)
        Me.editjual.Name = "editjual"
        Me.editjual.Size = New System.Drawing.Size(112, 36)
        Me.editjual.TabIndex = 35
        Me.editjual.Text = "EDIT"
        Me.editjual.UseVisualStyleBackColor = False
        '
        'bataljual
        '
        Me.bataljual.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.bataljual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bataljual.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.bataljual.Location = New System.Drawing.Point(490, 329)
        Me.bataljual.Name = "bataljual"
        Me.bataljual.Size = New System.Drawing.Size(112, 36)
        Me.bataljual.TabIndex = 34
        Me.bataljual.Text = "BATAL"
        Me.bataljual.UseVisualStyleBackColor = False
        '
        'hapusjual
        '
        Me.hapusjual.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.hapusjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hapusjual.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.hapusjual.Location = New System.Drawing.Point(343, 329)
        Me.hapusjual.Name = "hapusjual"
        Me.hapusjual.Size = New System.Drawing.Size(112, 36)
        Me.hapusjual.TabIndex = 33
        Me.hapusjual.Text = "HAPUS"
        Me.hapusjual.UseVisualStyleBackColor = False
        '
        'simpanjual
        '
        Me.simpanjual.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.simpanjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simpanjual.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.simpanjual.Location = New System.Drawing.Point(39, 329)
        Me.simpanjual.Name = "simpanjual"
        Me.simpanjual.Size = New System.Drawing.Size(112, 36)
        Me.simpanjual.TabIndex = 32
        Me.simpanjual.Text = "SIMPAN"
        Me.simpanjual.UseVisualStyleBackColor = False
        '
        'tglhargajual
        '
        Me.tglhargajual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tglhargajual.Location = New System.Drawing.Point(213, 163)
        Me.tglhargajual.Name = "tglhargajual"
        Me.tglhargajual.Size = New System.Drawing.Size(164, 26)
        Me.tglhargajual.TabIndex = 31
        '
        'namaprodukjual
        '
        Me.namaprodukjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.namaprodukjual.FormattingEnabled = True
        Me.namaprodukjual.Items.AddRange(New Object() {"Gram", "KG", "Liter", "ml"})
        Me.namaprodukjual.Location = New System.Drawing.Point(682, 165)
        Me.namaprodukjual.Name = "namaprodukjual"
        Me.namaprodukjual.Size = New System.Drawing.Size(165, 27)
        Me.namaprodukjual.TabIndex = 30
        '
        'jmlprodukjual
        '
        Me.jmlprodukjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.jmlprodukjual.Location = New System.Drawing.Point(213, 240)
        Me.jmlprodukjual.Name = "jmlprodukjual"
        Me.jmlprodukjual.Size = New System.Drawing.Size(165, 26)
        Me.jmlprodukjual.TabIndex = 29
        '
        'idhppjual
        '
        Me.idhppjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idhppjual.FormattingEnabled = True
        Me.idhppjual.Items.AddRange(New Object() {"Gram", "KG", "Liter", "ml"})
        Me.idhppjual.Location = New System.Drawing.Point(213, 199)
        Me.idhppjual.Name = "idhppjual"
        Me.idhppjual.Size = New System.Drawing.Size(165, 27)
        Me.idhppjual.TabIndex = 28
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(494, 243)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(73, 19)
        Me.Label29.TabIndex = 27
        Me.Label29.Text = "Harga Jual"
        '
        'profit
        '
        Me.profit.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.profit.Location = New System.Drawing.Point(682, 202)
        Me.profit.Name = "profit"
        Me.profit.Size = New System.Drawing.Size(165, 26)
        Me.profit.TabIndex = 26
        '
        'idprodukjual
        '
        Me.idprodukjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idprodukjual.Location = New System.Drawing.Point(682, 126)
        Me.idprodukjual.Name = "idprodukjual"
        Me.idprodukjual.Size = New System.Drawing.Size(165, 26)
        Me.idprodukjual.TabIndex = 25
        '
        'hargajual
        '
        Me.hargajual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hargajual.Location = New System.Drawing.Point(682, 240)
        Me.hargajual.Name = "hargajual"
        Me.hargajual.Size = New System.Drawing.Size(165, 26)
        Me.hargajual.TabIndex = 24
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(494, 202)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(42, 19)
        Me.Label30.TabIndex = 23
        Me.Label30.Text = "Profit"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(494, 170)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(95, 19)
        Me.Label31.TabIndex = 22
        Me.Label31.Text = "Nama Produk"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(494, 133)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(74, 19)
        Me.Label32.TabIndex = 21
        Me.Label32.Text = "ID Produk"
        '
        'hppjual
        '
        Me.hppjual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hppjual.Location = New System.Drawing.Point(213, 275)
        Me.hppjual.Name = "hppjual"
        Me.hppjual.Size = New System.Drawing.Size(165, 26)
        Me.hppjual.TabIndex = 19
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(25, 275)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(149, 19)
        Me.Label24.TabIndex = 18
        Me.Label24.Text = "Harga Pokok Produksi"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(25, 243)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(108, 19)
        Me.Label25.TabIndex = 17
        Me.Label25.Text = "Jumlah Produksi"
        '
        'idhargajual
        '
        Me.idhargajual.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.idhargajual.Location = New System.Drawing.Point(213, 126)
        Me.idhargajual.Name = "idhargajual"
        Me.idhargajual.Size = New System.Drawing.Size(165, 26)
        Me.idhargajual.TabIndex = 14
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(25, 202)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(58, 19)
        Me.Label26.TabIndex = 13
        Me.Label26.Text = "ID HPP"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(25, 170)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(55, 19)
        Me.Label27.TabIndex = 12
        Me.Label27.Text = "Tanggal"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(25, 133)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(93, 19)
        Me.Label28.TabIndex = 11
        Me.Label28.Text = "ID Harga Jual"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.combooverhead)
        Me.GroupBox4.Controls.Add(Me.hpptotaloverhead)
        Me.GroupBox4.Controls.Add(Me.addoverhead)
        Me.GroupBox4.Controls.Add(Me.Label34)
        Me.GroupBox4.Controls.Add(Me.Label35)
        Me.GroupBox4.Controls.Add(Me.Label36)
        Me.GroupBox4.Controls.Add(Me.hpphargaoverhead)
        Me.GroupBox4.Controls.Add(Me.hppidoverhead)
        Me.GroupBox4.Controls.Add(Me.Label37)
        Me.GroupBox4.Controls.Add(Me.hppsatuanoverhead)
        Me.GroupBox4.Controls.Add(Me.Label39)
        Me.GroupBox4.Location = New System.Drawing.Point(10, 364)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(699, 125)
        Me.GroupBox4.TabIndex = 35
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Biaya Overhead"
        '
        'hpptotaloverhead
        '
        Me.hpptotaloverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hpptotaloverhead.Location = New System.Drawing.Point(409, 56)
        Me.hpptotaloverhead.Name = "hpptotaloverhead"
        Me.hpptotaloverhead.Size = New System.Drawing.Size(163, 26)
        Me.hpptotaloverhead.TabIndex = 34
        '
        'addoverhead
        '
        Me.addoverhead.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.addoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.addoverhead.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.addoverhead.Location = New System.Drawing.Point(587, 50)
        Me.addoverhead.Name = "addoverhead"
        Me.addoverhead.Size = New System.Drawing.Size(93, 36)
        Me.addoverhead.TabIndex = 30
        Me.addoverhead.Text = "Add"
        Me.addoverhead.UseVisualStyleBackColor = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(1, 92)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(99, 19)
        Me.Label34.TabIndex = 31
        Me.Label34.Text = "Harga / Satuan"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(292, 56)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 19)
        Me.Label35.TabIndex = 33
        Me.Label35.Text = "Total"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(291, 24)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(69, 19)
        Me.Label36.TabIndex = 26
        Me.Label36.Text = "Overhead"
        '
        'hpphargaoverhead
        '
        Me.hpphargaoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hpphargaoverhead.Location = New System.Drawing.Point(109, 92)
        Me.hpphargaoverhead.Name = "hpphargaoverhead"
        Me.hpphargaoverhead.Size = New System.Drawing.Size(163, 26)
        Me.hpphargaoverhead.TabIndex = 32
        '
        'hppidoverhead
        '
        Me.hppidoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hppidoverhead.Location = New System.Drawing.Point(110, 21)
        Me.hppidoverhead.Name = "hppidoverhead"
        Me.hppidoverhead.Size = New System.Drawing.Size(163, 26)
        Me.hppidoverhead.TabIndex = 24
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(1, 60)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(50, 19)
        Me.Label37.TabIndex = 27
        Me.Label37.Text = "Satuan"
        '
        'hppsatuanoverhead
        '
        Me.hppsatuanoverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hppsatuanoverhead.Location = New System.Drawing.Point(109, 57)
        Me.hppsatuanoverhead.Name = "hppsatuanoverhead"
        Me.hppsatuanoverhead.Size = New System.Drawing.Size(163, 26)
        Me.hppsatuanoverhead.TabIndex = 29
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(1, 24)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(89, 19)
        Me.Label39.TabIndex = 22
        Me.Label39.Text = "ID Overhead"
        '
        'DataGridView5
        '
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Location = New System.Drawing.Point(738, 372)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.Size = New System.Drawing.Size(598, 110)
        Me.DataGridView5.TabIndex = 36
        '
        'combobb
        '
        Me.combobb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combobb.FormattingEnabled = True
        Me.combobb.Location = New System.Drawing.Point(413, 22)
        Me.combobb.Name = "combobb"
        Me.combobb.Size = New System.Drawing.Size(162, 27)
        Me.combobb.TabIndex = 22
        '
        'combopekerjaan
        '
        Me.combopekerjaan.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combopekerjaan.FormattingEnabled = True
        Me.combopekerjaan.Location = New System.Drawing.Point(409, 24)
        Me.combopekerjaan.Name = "combopekerjaan"
        Me.combopekerjaan.Size = New System.Drawing.Size(162, 27)
        Me.combopekerjaan.TabIndex = 35
        '
        'combooverhead
        '
        Me.combooverhead.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.combooverhead.FormattingEnabled = True
        Me.combooverhead.Location = New System.Drawing.Point(409, 21)
        Me.combooverhead.Name = "combooverhead"
        Me.combooverhead.Size = New System.Drawing.Size(162, 27)
        Me.combooverhead.TabIndex = 35
        '
        'comboproduk
        '
        Me.comboproduk.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboproduk.FormattingEnabled = True
        Me.comboproduk.Location = New System.Drawing.Point(415, 45)
        Me.comboproduk.Name = "comboproduk"
        Me.comboproduk.Size = New System.Drawing.Size(162, 27)
        Me.comboproduk.TabIndex = 33
        '
        'hpp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.MediumPurple
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "hpp"
        Me.Text = "hpp"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Produksi.ResumeLayout(False)
        Me.Produksi.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Produksi As GroupBox
    Friend WithEvents idproduk As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents idproduksi As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents addproduksi As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents totalpekerjaan As TextBox
    Friend WithEvents addpekerja As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents jmlpekerjaan As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents hargapekerjaan As TextBox
    Friend WithEvents idpekerjaan As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents satuanpekerjaan As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents totalbb As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents hargabb As TextBox
    Friend WithEvents addbb As Button
    Friend WithEvents satuanbb As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents idbb As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents jmlbb As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label23 As Label
    Friend WithEvents totalbbhpp As TextBox
    Friend WithEvents totalhpp As TextBox
    Friend WithEvents hitunghpp As Button
    Friend WithEvents totaloverhpp As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents produkhpp As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents totalpekerjahpp As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents jmlhpp As TextBox
    Friend WithEvents idhpp As TextBox
    Friend WithEvents simpanhpp As Button
    Friend WithEvents DataGridView4 As DataGridView
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents hppjual As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents idhargajual As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents tglproduksi As DateTimePicker
    Friend WithEvents tglhargajual As DateTimePicker
    Friend WithEvents namaprodukjual As ComboBox
    Friend WithEvents jmlprodukjual As TextBox
    Friend WithEvents idhppjual As ComboBox
    Friend WithEvents Label29 As Label
    Friend WithEvents profit As TextBox
    Friend WithEvents idprodukjual As TextBox
    Friend WithEvents hargajual As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents editjual As Button
    Friend WithEvents bataljual As Button
    Friend WithEvents hapusjual As Button
    Friend WithEvents simpanjual As Button
    Friend WithEvents Label33 As Label
    Friend WithEvents DataGridView5 As DataGridView
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents hpptotaloverhead As TextBox
    Friend WithEvents addoverhead As Button
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents hpphargaoverhead As TextBox
    Friend WithEvents hppidoverhead As TextBox
    Friend WithEvents Label37 As Label
    Friend WithEvents hppsatuanoverhead As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents combooverhead As ComboBox
    Friend WithEvents combopekerjaan As ComboBox
    Friend WithEvents combobb As ComboBox
    Friend WithEvents comboproduk As ComboBox
End Class
